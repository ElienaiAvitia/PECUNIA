package com.example.pecunia_elibeluies;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Progreso extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_progreso);

        String usuario = getIntent().getStringExtra("UserName");
    }
}
