package com.example.pecunia_elibeluies;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.CursorAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import androidx.appcompat.app.AppCompatActivity;

import com.example.pecunia_elibeluies.db.dbPecunia;


public class Distribucion extends AppCompatActivity {
    //private ListView listView;


    //pa obtener el folio
    //int folioUsuario = DbPecunia.obtenerFolio(usuario);

    //ListView miLista = findViewById(R.id.lvDistribucion);
   // @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_distribucion);

        //listView = findViewById(R.id.lvDistribucion);
        String usuario = getIntent().getStringExtra("UserName");

        mostrarDatos();
    }

    private void mostrarDatos() {
        ListView miLista = findViewById(R.id.lvDistribucion);
        dbPecunia DbPecunia = new dbPecunia(Distribucion.this);
       // SQLiteDatabase db = DbPecunia.getWritableDatabase();

        Cursor cursor = DbPecunia.obtenerEgresos();
        String[] fromColumns = new String[] { "Concepto", "Tipo", "Fecha", "Cantidad" };
        int[] toViews = new int[] { R.id.concepto, R.id.tipo, R.id.fecha, R.id.cantidad }; // IDs de tus vistas

        try {
            CursorAdapter adapter = new SimpleCursorAdapter(this, R.layout.items_listview, cursor, fromColumns, toViews, 0);
            miLista.setAdapter(adapter);
        } catch (Exception e) {
            e.printStackTrace();
        }


        //CursorAdapter adapter = new SimpleCursorAdapter(this, R.layout.items_listview, cursor, fromColumns, toViews, 0);
//aqui es donde se manda la variable con la q se enlazo
       //miLista.setAdapter(adapter);
        cursor.close();
    }
    /*private void mostrarDatos() {
        dbPecunia DbPecunia = new dbPecunia(Distribucion.this);
       // SQLiteDatabase db = DbPecunia.getWritableDatabase();
        Cursor cursor = DbPecunia.obtenerDatos();
        String[] fromColumns = {
                dbPecunia.DB_TABLE_EGRESOS + ".Concepto",
                dbPecunia.DB_TABLE_EGRESOS + ".Tipo",
                // Agrega más columnas según sea necesario
        };
        int[] toViews = {android.R.id.text1};


        CursorAdapter cursorAdapter = new SimpleCursorAdapter(
                this,
                android.R.layout.simple_list_item_1,
                cursor,
                fromColumns,
                toViews,
                0
        );

        listView.setAdapter(cursorAdapter);
        cursor.close();
    }*/
}
