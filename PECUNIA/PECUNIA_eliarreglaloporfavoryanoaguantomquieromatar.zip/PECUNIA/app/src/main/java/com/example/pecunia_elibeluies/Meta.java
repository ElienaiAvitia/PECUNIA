package com.example.pecunia_elibeluies;

import android.annotation.SuppressLint;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.pecunia_elibeluies.db.dbPecunia;
import com.google.android.material.textfield.TextInputLayout;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Meta extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meta);

        String usuario = getIntent().getStringExtra("UserName");

        Button btnAceptar;
        EditText txtConcepto, txtCantidadAlcanzar, txtFechaLimite, txtCantidadRecaudada;

        // txtNombre= findViewById(R.id.txtNombreMeta);
        txtConcepto = findViewById(R.id.txtConcepto);
        txtCantidadAlcanzar = findViewById(R.id.txtCantidadAlcanzar);
        txtFechaLimite = findViewById(R.id.txtFechaLimite);
        txtCantidadRecaudada = findViewById(R.id.txtCantidadRecaudada);

        btnAceptar = findViewById(R.id.btnAceptar);

        btnAceptar.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                String concepto = txtConcepto.getText().toString();
                String cantidadAlc = txtCantidadAlcanzar.getText().toString();
                String cantidadRec = txtCantidadRecaudada.getText().toString();
                String fechaLimite = txtFechaLimite.getText().toString();
                Double cantidadA = Double.parseDouble(cantidadAlc);
                Double cantidadR = Double.parseDouble(cantidadRec);

                Date fechaActual = new Date();
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                String fechaIni = dateFormat.format(fechaActual);
                String fechaLim = dateFormat.format(fechaLimite);

                dbPecunia DbPecunia = new dbPecunia(Meta.this);
                SQLiteDatabase db = DbPecunia.getWritableDatabase();

                //pa obtener el folio
                int folioUsuario = DbPecunia.obtenerFolio(usuario);

                if (db != null) {
                    //Toast.makeText(Fijos.this, "bd si", Toast.LENGTH_SHORT).show();
                    Long in = DbPecunia.insertarMeta(fechaIni, fechaLim, cantidadR, cantidadA, concepto, folioUsuario);
                    if (in > 0) {
                        Toast.makeText(Meta.this, "Guardado exitosamente", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(Meta.this, "Error al guardar", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

    }
}
